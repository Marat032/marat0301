﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helloworld
{
    public partial class Form1 : Form
    {
        private object lblHelloWorld;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            iblhelloworld.Text = "Hello World!";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            iblhelloworld.Text = "Hello World!";
        }

        private void iblhelloworld_Click(object sender, EventArgs e)
        {

        }
    }
}
